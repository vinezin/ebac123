import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import silhouette_score

# 1. COLETA
df = pd.read_csv('dados/credito.csv')
print(f"📊 Dados: {df.shape}")

# 2. MODELAGEM
X = df[['idade', 'renda']].fillna(0)
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)
kmeans = KMeans(n_clusters=3, random_state=42)
df['cluster'] = kmeans.fit_predict(X_scaled)

score = silhouette_score(X_scaled, df['cluster'])
print(f"✅ Silhouette: {score:.2f}")

# 3. VISUALIZAÇÃO
plt.figure(figsize=(10,6))
sns.scatterplot(data=df, x='idade', y='renda', hue='cluster', palette='viridis')
plt.title('Clusters de Risco Crédito (K-Means)')
plt.savefig('clusters.png')
plt.show()

print("🏆 Projeto Completo!")
